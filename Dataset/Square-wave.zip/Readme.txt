REF : T. Phungtua-eng, Y. Yamamoto, and S. Sako. 2023. Elastic Data Binning for Transient Pattern Analysis in Time-Domain Astrophysics. In Proceedings of the 38th Annual ACM Symposium on Applied Computing (SAC '23). 
DOI : https://doi.org/10.1145/3555776.3577606
URL : https://sites.google.com/view/elasticdatabinning


Introduction
	LCs dataset provided was obtained from the Tomo-e Gozen project of the Kiso Schmidt telescope. For more detail, visit https://tomoe.mtk.ioa.s.u-tokyo.ac.jp/
	Notably, we applied the z-normalization to each LC for evaluation.
	
NAMING FOLDER
	•Naming folder format is  "<pattern>_<height>_<duration>"
		◦<pattern> denotes the type of the transient pattern.
		◦<height> denotes the height of the transient pattern.
		◦<duration> denotes the duration of the transient pattern.

NAMEING FILE
	•Naming file format is "<running number>_<starting point of transient pattern>_<ending point of transient pattern>.txt"
		◦For example : "001_130_189.txt"
		◦Transient pattern occurs at timestamps between 130 to 189 (60 duration). 
		◦Notably, all files are Zero-based numbering

